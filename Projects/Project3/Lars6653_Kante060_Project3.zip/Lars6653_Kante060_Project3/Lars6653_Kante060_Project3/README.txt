Group Members:
Tyler Larson - lars6653
Connor Kanten - kante060

Contributions:
Tyler:
    - LinkedList.java

Connor:
    - ArrayList.java

How to Compile/Run:
    - Compiled and Tested in VS Code and IntelliJ, so should work in either.
    - Runs only using JUnit tests (no main methods)

Assumptions:
    - Using Java 11

Additional Features:
    - None

Bugs and Defects:
    - None known

Outside Sources:
    - Insertion Sort from 1933 Canvas Page
    - Reverse Linked List from 1933 Canvas Page



I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.

Tyler Larsen
Connor Kanten