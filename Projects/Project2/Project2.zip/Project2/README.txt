Group Members:
Tyler Larson - lars6653
Connor Kanten - kante060

Contributions:
Tyler:
    - Board class methods
    - Game functionality

Connor:
    - Piece .isMoveLegal() methods
    - User input interpreter
    - Pawn promotion

How to Compile/Run:
    - Use chcp 65001 in terminal to enable Unicode characters
    - Run from Game.java
    - Compiled with Java Runtime Version 19

Assumptions:
    - N/A

Additional Features:
    - N/A

Bugs and Defects:
    - None known

Outside Sources:
    - 1. Documentation for Character class - https://docs.oracle.com/javase/6/docs/api/java/lang/Character.html#isWhitespace%28char%29 



I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.

Tyler Larsen
Connor Kanten